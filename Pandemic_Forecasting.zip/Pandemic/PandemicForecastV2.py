from selenium import webdriver
from datetime import datetime, timedelta
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA
import matplotlib.pyplot as plt
from bs4 import BeautifulSoup
from xml.etree import ElementTree as ET
from selenium.webdriver.chrome.service import Service
import os

# Function uses Selenium and BeautifulSoup to scrape COVID-19 daily cases statistics for South Africa
def get_daily_cases():
    try:
        options = webdriver.ChromeOptions()
        
        options.add_argument('--headless')

        local_dir = os.path.dirname(os.path.abspath(__file__))
        driver_path = os.path.join(local_dir, 'chromedriver.exe')
        ser=Service(driver_path)
        # Start a new instance of Chrome WebDriver
        driver = webdriver.Chrome(service=ser,options=options)
        driver.get("https://www.worldometers.info/coronavirus/country/south-africa/")

        soup=BeautifulSoup(driver.page_source,'html.parser')
        #Get the graph using it's class (found below class on web inspection page)
        response=soup.find('g', {'class':'highcharts-series highcharts-series-0 highcharts-column-series highcharts-tracker highcharts-dense-data'})
        #put all the elements found in a list
        res=response.find_all("rect")

        data_points = []
        # Parse the XML string to be able to easily get the Y and Height attributes for every co-ordinate in the graph
        for rect_element in res:
            root = ET.fromstring(rect_element.prettify())
            
            # Extract attributes
            x = float(root.attrib['x'])
            y = float(root.attrib['y'])
            width = float(root.attrib['width'])
            height = float(root.attrib['height'])
            
            # Append to data_points list
            data_points.append({y,height})
        
        driver.quit()

        return data_points
    except Exception as e:
        print(f"An error occurred: {e}")
        return None


# Function to generate the forecast using ARIMA model
def generate_forecast(data_points):
    # use the Y-coordinate and height to represent the data values
    daily_cases =[]
    for y, height in data_points:
        daily_cases.append(height)
    # ARIMA model
    arima_model = ARIMA(daily_cases, order=(5,1,0))
    arima_fit = arima_model.fit()

    # forecast for next 7 days
    forecast = arima_fit.forecast(steps=7)
    
    return forecast

# Function to save results to CSV file, .png file and generate the forecast (plot)
def saveResults_and_plot(forecast):
    # Generating dates for the next 7 days
    today_date = datetime.now().date()
    future_dates =[]
    for i in range(1,8):
        future_dates.append(today_date + timedelta(days=i))

    # Combine dates and forecasted values
    forecast_df = pd.DataFrame({'date': future_dates, 'new_cases': forecast})

    # Writing results to a .csv file
    script_dir = os.path.dirname(os.path.abspath(__file__))
    csv_path = os.path.join(script_dir, 'Daily_cases.csv')
    forecast_df.to_csv(csv_path, index=False)

    # Generating timeseries plot
    plt.figure(figsize=(10, 6))
    plt.plot(forecast_df['date'], forecast_df['new_cases'], label='Forecast')
    plt.xlabel('Date')
    plt.ylabel('New Daily Cases')
    plt.title('7-Days COVID-19 Forecast for South Africa')
    plt.legend()
    png_path = os.path.join(script_dir, 'forecast.png')
    plt.savefig(png_path)
    plt.show()


def main():
    try:
        data_points = get_daily_cases()
        forecast = generate_forecast(data_points)

        saveResults_and_plot(forecast)

        # Points on how the model can be improved
        Modelimprovement_recommendations = """
        To improve forecast accuracy, additional data sources such as:
        - Data on the movement of people - This influences the spread of the virus (The more people move around the more likely new cases will increase)
        - Information about the healthcare infrastructure of the country (capacity and resource availability)
        -  Take into consideration government policies, such as lockdown which is likely to reduce the number of new daily cases
        - Vaccination data- it's Efficiency and vaccination availability 
        """
        local_dir = os.path.dirname(os.path.abspath(__file__))
        file_path = os.path.join(local_dir, 'improvement.txt')
        with open(file_path, 'w') as improvement:
            improvement.write(Modelimprovement_recommendations)
    except Exception as e:
        print(f"An error occurred: {e}, ensure you have internet connection")

if __name__ == "__main__":
    main()